var default_content="";
var curPrice;
var selectedCurrency;
var exchRate;

$(document).ready(function(){


	checkURL();
	$('ul li a').click(function (e){
			checkURL(this.hash);
	});
	$("#currency").change(function() {
		
		loadCurrency($("#currency").val());
		//alert($('#currency').val());
		//$("#currency").val();
		
	});
	$("#schedule").change(function() {
		loadSchedule($("#schedule").val());
		//alert($('#schedule').val());
		//$("#courseDetails").val();	
	});
	$("#target").submit(function(event){
		alert("Handler for .submit() called.");
		event.preventDefault();
		//console.log('Trigger');
});
	//filling in the default content
	default_content = $('#pageContent').html();
  
//link to another page after clicking on dates in #page2
$("a").click(function(){
//this refers to anchor text//
});

	setInterval("checkURL()",250);

});

var lasturl="";

function checkURL(hash)
{
	if(!hash) hash=window.location.hash;
	if(hash != lasturl)
	{
		lasturl=hash;
		// FIX - if we've used the history buttons to return to the homepage,
		// fill the pageContent with the default_content
		if(hash=="")
		$('#pageContent').html(default_content);

		else{
		 if(hash=="#products")
				loadProducts();
			
			
		 else
		   loadPage(hash);
		}
	}
}


function loadPage(url)
{
	url=url.replace('#','');

	$('#loading').css('visibility','visible');

	$.ajax({
		type: "POST",
		url: "load_page.jsp",
		data: 'page='+url,
		dataType: "html",
		success: function(msg){

			if(parseInt(msg)!=0)
			{
				$('#pageContent').html(msg);
				$('#loading').css('visibility','hidden');
				
			}
		}
	});
}
function loadProducts() {
	$('#loading').css('visibility','visible');
	var jsonURL = "products.json";
	$.getJSON(jsonURL, function (json)
	{
	  var imgList= "<ul class=\"products\">";
	  $.each(json.products, function () {
		//imgList += '<li><img src= "' + this.imgPath + '" onclick ="loadDetails(\'' + this.name + '\', \' + this.price + '\')"><h3>' + this.name + '</h3></li>';
		imgList += "<li>" +
	             	"<img src= \" + this.imgPath + \" " +
                     "onclick = \"loadDetails('" + this.name + "','"  + this.price + "')\" >"+
               " <h3>" + this.name + "</h3>"
              "</li>";
	  });
	  imgList+='</ul>'
	 $('#pageContent').html(imgList);
	 $('#loading').css('visibility','hidden');
	});
  }
  
  function loadDetails(selectedProduct, price){
	  $('#loading').css('visibility','visible');
	  var jsonURL = "products.json";
		var imgList;
		curPrice = price;
	  $.getJSON(jsonURL, function (json)
	  {
		
		$.each(json.products, function () {
			  if (this.name === selectedProduct){
				//   imgList = '<li><img src= " ' + this.id +  this.name + this. description +'"></img></li>';
				imgList = "<li><img src='" + this.imgPath + "'><h4>" + this.name + "</h4><p>" + this.description +  
				"</p><p id=\"countrycurrency\">" + this.price + "</p><p>" +'<a href=\"'+ this.date +'\"'+ '><\a>'+"</p></li>";
			
			  }
	  });
	  imgList+='</ul>'
	 $('#pageContent').html(imgList);
	 $('#loading').css('visibility','hidden');
	});
	}
	/*function loadSchedule(selectedCourseName){
	  $('#loading').css('visibility','visible');
	  var jsonURL = "schedule.json";
	  var imgList;
	  $.getJSON(jsonURL, function (json)
	  {
		
		$.each(json.schedule, function () {
			  if (this.course_name === selectedCourseName){
				//   imgList = '<li><img src= " ' + this.id +  this.name + this. description +'"></img></li>';
				imgList = "<li><img src='" + this.imgPath + "'><h5>" + this.name +"</h5><p>" + this.description + "</p>" + this.price + "</p><p id=\"courseschedule\">"+ this.course_date + "<p></li>";
			
			  }
	  });
	  imgList+='</ul>'
	 $('#pageContent').html(imgList);
	 $('#loading').css('visibility','hidden');
	});
  }*/
  function loadCurrency(selectedCurrency) {
	$('#loading').css('visibility','visible');
	//alert(selectedCurrency);//
	selectedCurrency = selectedCurrency;
	var jsonURL = "currency.json";
	$.getJSON(jsonURL, function (json)
	{
	  $.each(json.currencies, function () {
		if(this.code === selectedCurrency){
			var price = this.conversion * curPrice;
		$("#countrycurrency").html(price);

		}
	  }	);
	 $('#loading').css('visibility','hidden');
	});
}

	/*function loadSchedule(selectedCourseName) {
		$('#loading').css('visibility','visible');
		//alert(selectedCourseName);//
		var jsonURL = "schedule.json";
		$.getJSON(jsonURL, function (json)
		{
		  $.each(json.course, function () {
			if(this.course_name === selectedCourseName){
			$("#courseschedule").html(this.course_date);
			}
		  }	);
		 $('#loading').css('visibility','hidden');
		});
	}*/
	
