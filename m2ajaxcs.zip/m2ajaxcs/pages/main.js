$('form.ajax').on('submit',function(){
    //console.log('Trigger');

    return false;
    
});